package com.chuckegg.hytrackhud;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.class_310;

public final class HyTrackConfig {

private static final Gson GSON =
        new GsonBuilder()
                .setPrettyPrinting()
                .create();

public static final String DEFAULT_FORMAT =
        "Players: {count} ({delta})";

public static final String DEFAULT_BACKGROUND_COLOR =
        "#000000";

public static String textFormat =
        DEFAULT_FORMAT;

public static String backgroundColor =
        DEFAULT_BACKGROUND_COLOR;

public static double x = 1.0;
public static double y = 1.0;
public static double scale = 1.0;

public static double backgroundOpacity =
        0.25;

private HyTrackConfig() {
}

private static Path getConfigPath() {

    class_310 client =
            class_310.method_1551();

    return client.field_1697
            .toPath()
            .resolve("config")
            .resolve("hytrack_player_count.json");
}

public static void load() {

    Path path = getConfigPath();

    if (!Files.exists(path)) {
        save();
        return;
    }

    try {

        String contents =
                Files.readString(
                        path,
                        StandardCharsets.UTF_8
                );

        JsonObject json =
                JsonParser.parseString(contents)
                        .getAsJsonObject();

        if (json.has("textFormat")) {
            textFormat =
                    json.get("textFormat")
                            .getAsString();
        }

        if (json.has("backgroundColor")) {
            backgroundColor =
                    json.get("backgroundColor")
                            .getAsString();
        }

        if (json.has("x")) {
            x =
                    json.get("x")
                            .getAsDouble();
        }

        if (json.has("y")) {
            y =
                    json.get("y")
                            .getAsDouble();
        }

        if (json.has("scale")) {
            scale =
                    json.get("scale")
                            .getAsDouble();
        }

        if (json.has("backgroundOpacity")) {
            backgroundOpacity =
                    json.get("backgroundOpacity")
                            .getAsDouble();
        }

        clamp();

    } catch (Exception ignored) {

        reset();
    }
}

public static void save() {

    clamp();

    try {

        Path path =
                getConfigPath();

        Files.createDirectories(
                path.getParent()
        );

        JsonObject json =
                new JsonObject();

        json.addProperty(
                "textFormat",
                textFormat
        );

        json.addProperty(
                "backgroundColor",
                backgroundColor
        );

        json.addProperty(
                "x",
                x
        );

        json.addProperty(
                "y",
                y
        );

        json.addProperty(
                "scale",
                scale
        );

        json.addProperty(
                "backgroundOpacity",
                backgroundOpacity
        );

        Files.writeString(
                path,
                GSON.toJson(json),
                StandardCharsets.UTF_8
        );

    } catch (IOException ignored) {
    }
}

public static void reset() {

    textFormat =
            DEFAULT_FORMAT;

    backgroundColor =
            DEFAULT_BACKGROUND_COLOR;

    x = 1.0;
    y = 1.0;
    scale = 1.0;

    backgroundOpacity =
            0.25;

    save();
}

public static int getBackgroundRgb() {

    try {

        String hex =
                backgroundColor
                        .trim()
                        .replace("#", "");

        if (hex.length() != 6) {
            return 0x000000;
        }

        return Integer.parseInt(
                hex,
                16
        );

    } catch (Exception ignored) {

        return 0x000000;
    }
}

private static void clamp() {

    if (textFormat == null ||
            textFormat.isBlank()) {

        textFormat =
                DEFAULT_FORMAT;
    }

    if (backgroundColor == null ||
            !backgroundColor.matches(
                    "#[0-9a-fA-F]{6}"
            )) {

        backgroundColor =
                DEFAULT_BACKGROUND_COLOR;
    }

    x =
            Math.max(
                    0.0,
                    Math.min(100.0, x)
            );

    y =
            Math.max(
                    0.0,
                    Math.min(100.0, y)
            );

    scale =
            Math.max(
                    0.5,
                    Math.min(2.5, scale)
            );

    backgroundOpacity =
            Math.max(
                    0.0,
                    Math.min(1.0, backgroundOpacity)
            );
}

}
