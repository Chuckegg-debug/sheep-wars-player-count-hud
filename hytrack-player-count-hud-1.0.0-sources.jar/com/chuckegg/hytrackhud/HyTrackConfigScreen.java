package com.chuckegg.hytrackhud;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class HyTrackConfigScreen extends class_437 {

private final class_437 parent;

private class_342 formatField;
private class_342 colorField;
private class_342 xField;
private class_342 yField;

private ConfigSlider scaleSlider;
private ConfigSlider opacitySlider;

public HyTrackConfigScreen(class_437 parent) {
    super(
            class_2561.method_43470(
                    "HyTrack Player Count HUD"
            )
    );

    this.parent = parent;
}

@Override
protected void method_25426() {

    super.method_25426();

    int centerX =
            this.field_22789 / 2;

    int fieldWidth = 300;

    int left =
            centerX - fieldWidth / 2;

    // Text format
    formatField =
            new class_342(
                    this.field_22793,
                    left,
                    45,
                    fieldWidth,
                    20,
                    class_2561.method_43470("Text format")
            );

    formatField.method_1852(
            HyTrackConfig.textFormat
    );

    formatField.method_1880(200);

    this.method_37063(
            formatField
    );

    // Background color
    colorField =
            new class_342(
                    this.field_22793,
                    left,
                    95,
                    fieldWidth,
                    20,
                    class_2561.method_43470("Background color")
            );

    colorField.method_1852(
            HyTrackConfig.backgroundColor
    );

    colorField.method_1880(7);

    this.method_37063(
            colorField
    );

    // X position
    xField =
            new class_342(
                    this.field_22793,
                    left,
                    145,
                    fieldWidth,
                    20,
                    class_2561.method_43470("X position")
            );

    xField.method_1852(
            String.valueOf(
                    HyTrackConfig.x
            )
    );

    xField.method_1880(10);

    this.method_37063(
            xField
    );

    // Y position
    yField =
            new class_342(
                    this.field_22793,
                    left,
                    195,
                    fieldWidth,
                    20,
                    class_2561.method_43470("Y position")
            );

    yField.method_1852(
            String.valueOf(
                    HyTrackConfig.y
            )
    );

    yField.method_1880(10);

    this.method_37063(
            yField
    );

    // Scale
    scaleSlider =
            new ConfigSlider(
                    left,
                    245,
                    fieldWidth,
                    20,
                    (HyTrackConfig.scale - 0.5) / 2.0
            ) {

                @Override
                protected void method_25346() {

                    method_25355(
                            class_2561.method_43470(
                                    String.format(
                                            "Scale: %.2fx",
                                            HyTrackConfig.scale
                                    )
                            )
                    );
                }

                @Override
                protected void method_25344() {

                    HyTrackConfig.scale =
                            0.5
                                    + this.field_22753 * 2.0;
                }
            };

    scaleSlider.refreshMessage();

    this.method_37063(
            scaleSlider
    );

    // Background opacity
    opacitySlider =
            new ConfigSlider(
                    left,
                    295,
                    fieldWidth,
                    20,
                    HyTrackConfig.backgroundOpacity
            ) {

                @Override
                protected void method_25346() {

                    method_25355(
                            class_2561.method_43470(
                                    String.format(
                                            "Background opacity: %d%%",
                                            Math.round(
                                                    HyTrackConfig.backgroundOpacity
                                                            * 100
                                            )
                                    )
                            )
                    );
                }

                @Override
                protected void method_25344() {

                    HyTrackConfig.backgroundOpacity =
                            this.field_22753;
                }
            };

    opacitySlider.refreshMessage();

    this.method_37063(
            opacitySlider
    );

    // Reset
    this.method_37063(
            class_4185.method_46430(
                    class_2561.method_43470("Reset"),
                    button ->
                            resetFields()
            ).method_46434(
                    centerX - 155,
                    345,
                    100,
                    20
            ).method_46431()
    );

    // Done
    this.method_37063(
            class_4185.method_46430(
                    class_2561.method_43470("Done"),
                    button ->
                            saveAndClose()
            ).method_46434(
                    centerX + 55,
                    345,
                    100,
                    20
            ).method_46431()
    );
}

private void resetFields() {

    HyTrackConfig.reset();

    formatField.method_1852(
            HyTrackConfig.textFormat
    );

    colorField.method_1852(
            HyTrackConfig.backgroundColor
    );

    xField.method_1852(
            String.valueOf(
                    HyTrackConfig.x
            )
    );

    yField.method_1852(
            String.valueOf(
                    HyTrackConfig.y
            )
    );

    scaleSlider.setValuePublic(
            (HyTrackConfig.scale - 0.5) / 2.0
    );

    opacitySlider.setValuePublic(
            HyTrackConfig.backgroundOpacity
    );
}

private void saveAndClose() {

    HyTrackConfig.textFormat =
            formatField.method_1882();

    String enteredColor =
            colorField.method_1882()
                    .trim();

    if (enteredColor.matches(
            "#[0-9a-fA-F]{6}"
    )) {

        HyTrackConfig.backgroundColor =
                enteredColor;

    } else {

        colorField.method_1852(
                HyTrackConfig.backgroundColor
        );
    }

    try {

        HyTrackConfig.x =
                Double.parseDouble(
                        xField.method_1882()
                );

    } catch (NumberFormatException ignored) {
    }

    try {

        HyTrackConfig.y =
                Double.parseDouble(
                        yField.method_1882()
                );

    } catch (NumberFormatException ignored) {
    }

    HyTrackConfig.save();

    if (this.field_22787 != null) {

        this.field_22787.method_1507(
                parent
        );
    }
}

@Override
public void method_25419() {

    saveAndClose();
}

@Override
public void method_25394(
        class_332 context,
        int mouseX,
        int mouseY,
        float delta
) {

    int centerX =
            this.field_22789 / 2;

    context.method_27534(
            this.field_22793,
            this.field_22785,
            centerX,
            15,
            0xFFFFFFFF
    );

    context.method_27535(
            this.field_22793,
            class_2561.method_43470(
                    "Text format"
            ),
            centerX - 150,
            32,
            0xFFAAAAAA
    );

    context.method_27535(
            this.field_22793,
            class_2561.method_43470(
                    "Background color (#RRGGBB)"
            ),
            centerX - 150,
            82,
            0xFFAAAAAA
    );

    context.method_27535(
            this.field_22793,
            class_2561.method_43470(
                    "X position (0–100%)"
            ),
            centerX - 150,
            132,
            0xFFAAAAAA
    );

    context.method_27535(
            this.field_22793,
            class_2561.method_43470(
                    "Y position (0–100%)"
            ),
            centerX - 150,
            182,
            0xFFAAAAAA
    );

    context.method_27535(
            this.field_22793,
            class_2561.method_43470(
                    "Use {count} and {delta} in the format"
            ),
            centerX - 150,
            375,
            0xFFAAAAAA
    );

    super.method_25394(
            context,
            mouseX,
            mouseY,
            delta
    );
}

@Override
public boolean method_25421() {

    return false;
}

private abstract static class ConfigSlider
        extends class_357 {

    protected ConfigSlider(
            int x,
            int y,
            int width,
            int height,
            double value
    ) {

        super(
                x,
                y,
                width,
                height,
                class_2561.method_43473(),
                value
        );
    }

    public void setValuePublic(
            double value
    ) {

        method_25347(value);
        method_25346();
    }

    public void refreshMessage() {

        method_25346();
    }
}

}
