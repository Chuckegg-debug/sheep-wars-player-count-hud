package com.chuckegg.hytrackhud;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class HyTrackPlayerCountHudClient
implements ClientModInitializer {

private static final String ENDPOINT =
        "https://hytrack-status.chuckegg.workers.dev/";

private static final HttpClient HTTP =
        HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(3))
                .build();

private static final AtomicInteger PLAYERS =
        new AtomicInteger(-1);

private static final AtomicInteger DELTA =
        new AtomicInteger(Integer.MIN_VALUE);

private static final AtomicLong LAST_REQUEST =
        new AtomicLong(0);

private static boolean visible = true;

private static class_304 toggleKey;

@Override
public void onInitializeClient() {

    HyTrackConfig.load();

    toggleKey =
            KeyBindingHelper.registerKeyBinding(
                    new class_304(
                            "key.hytrack_player_count.toggle",
                            class_3675.class_307.field_1668,
                            GLFW.GLFW_KEY_F8,
                            class_304.class_11900.field_62556
                    )
            );

    ClientTickEvents.END_CLIENT_TICK.register(client -> {

        while (toggleKey.method_1436()) {
            visible = !visible;
        }

        long now =
                System.currentTimeMillis();

        if (now - LAST_REQUEST.get() >= 5000) {

            LAST_REQUEST.set(now);

            fetchPlayerCount();
        }
    });

    HudRenderCallback.EVENT.register(
            (drawContext, tickDelta) ->
                    render(drawContext)
    );
}

private static void fetchPlayerCount() {

    HttpRequest request =
            HttpRequest.newBuilder()
                    .uri(URI.create(ENDPOINT))
                    .timeout(Duration.ofSeconds(5))
                    .header(
                            "Accept",
                            "application/json"
                    )
                    .GET()
                    .build();

    HTTP.sendAsync(
            request,
            HttpResponse.BodyHandlers.ofString()
    ).thenAccept(response -> {

        if (response.statusCode() < 200 ||
                response.statusCode() >= 300) {

            PLAYERS.set(-1);
            DELTA.set(Integer.MIN_VALUE);

            return;
        }

        try {

            JsonObject json =
                    JsonParser.parseString(
                            response.body()
                    ).getAsJsonObject();

            int newPlayers =
                    json.get("players")
                            .getAsInt();

            int previousPlayers =
                    PLAYERS.getAndSet(newPlayers);

            if (previousPlayers >= 0) {

                DELTA.set(
                        newPlayers - previousPlayers
                );

            } else {

                DELTA.set(0);
            }

        } catch (Exception ignored) {

            PLAYERS.set(-1);
            DELTA.set(Integer.MIN_VALUE);
        }

    }).exceptionally(error -> {

        PLAYERS.set(-1);
        DELTA.set(Integer.MIN_VALUE);

        return null;
    });
}

public static String formatText(
        int players,
        int delta
) {

    String countText =
            players >= 0
                    ? String.valueOf(players)
                    : "--";

    String deltaText;

    if (delta == Integer.MIN_VALUE) {

        deltaText = "--";

    } else if (delta >= 0) {

        deltaText = "+" + delta;

    } else {

        deltaText = String.valueOf(delta);
    }

    return HyTrackConfig.textFormat
            .replace("{count}", countText)
            .replace("{delta}", deltaText);
}

private static void render(
        class_332 context
) {

    class_310 client =
            class_310.method_1551();

    if (!visible ||
            client.field_1724 == null ||
            client.field_1690.field_1842) {

        return;
    }

    int players =
            PLAYERS.get();

    int delta =
            DELTA.get();

    String text =
            formatText(
                    players,
                    delta
            );

    int paddingX = 5;
    int paddingY = 2;

    int textWidth =
            client.field_1772.method_1727(text);

    int textHeight =
            client.field_1772.field_2000;

    double scale =
            HyTrackConfig.scale;

    int width =
            (int) (
                    (textWidth + paddingX * 2)
                            * scale
            );

    int height =
            (int) (
                    (textHeight + paddingY * 2)
                            * scale
            );

    int screenWidth =
            context.method_51421();

    int screenHeight =
            context.method_51443();

    int maxX =
            Math.max(
                    0,
                    screenWidth - width
            );

    int maxY =
            Math.max(
                    0,
                    screenHeight - height
            );

    int x =
            (int) (
                    (HyTrackConfig.x / 100.0)
                            * maxX
            );

    int y =
            (int) (
                    (HyTrackConfig.y / 100.0)
                            * maxY
            );

    int opacity =
            (int) (
                    HyTrackConfig.backgroundOpacity
                            * 255.0
            );

    int rgb =
            HyTrackConfig.getBackgroundRgb();

    int backgroundColor =
            (opacity << 24) | rgb;

    /*
     * Plain Lunar-style background.
     *
     * No border.
     * No shadow.
     * No accent bars.
     */
    context.method_25294(
            x,
            y,
            x + width,
            y + height,
            backgroundColor
    );

    context.method_51448().pushMatrix();

    context.method_51448().translate(
            (float) x,
            (float) y
    );

    context.method_51448().scale(
            (float) scale,
            (float) scale
    );

    context.method_25303(
            client.field_1772,
            text,
            paddingX,
            paddingY,
            0xFFFFFFFF
    );

    context.method_51448().popMatrix();
}

}
